﻿namespace WPFControlsApp
{
    public class WpfControl
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
