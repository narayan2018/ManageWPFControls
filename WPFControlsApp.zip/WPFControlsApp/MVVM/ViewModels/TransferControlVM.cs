﻿
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace WPFControlsApp
{
    public class TransferControlVM
    {
        public ObservableCollection<WpfControl> ControlsListFirst { get; set; }
        public ObservableCollection<WpfControl> ControlsSecondList { get; set; }
        public TransferControlVM()
        {
            ControlsSecondList = new ObservableCollection<WpfControl>();
            ControlsListFirst = new ObservableCollection<WpfControl>();
            GetControlsList();
        }


        private WpfControl _selectedControls;
        public WpfControl SelectedControls
        {
            get
            {
                return _selectedControls;
            }
            set
            {
                _selectedControls = value;
            }
        }

        private ICommand _tranferControlsCommand;

        public ICommand TranferControlsCommand
        {
            get
            {
                return _tranferControlsCommand ?? (_tranferControlsCommand = new RelayCommand(TransferControls));
            }
        }

        private void TransferControls(object obj)
        {
            WpfControl cont = obj as WpfControl;
            if (cont != null)
            {
                ControlsSecondList.Add(new WpfControl() { Name = cont.Name });
            }
        }

        private void GetControlsList()
        {
            ControlsListFirst = new ObservableCollection<WpfControl>
            {
                
                new WpfControl() {Name="TextBox"},
                new WpfControl(){Name="TextBlock" },
                new WpfControl(){Name="Label" },
                new WpfControl() {Name="CheckBox"},
                new WpfControl() {Name="Button"}
               
            };
        }
    }
}
